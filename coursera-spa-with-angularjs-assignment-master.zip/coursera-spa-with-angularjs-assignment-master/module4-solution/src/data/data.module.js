(function () {
'use strict';

angular.module('data', [])
.constant('ApiBasePath', "https://davids-restaurant.herokuapp.com");

})();
